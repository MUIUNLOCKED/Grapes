const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'avatar',
  category: 'Information',
  aliases: ['av'],
  description: 'Check the avatar',
  args: false,
  usage: '',
  userPrams: [],
  botPrams: ['EMBED_LINKS'],

  execute(message, args) {
    // Get the mentioned user or use the message author if no user is mentioned
    const user = message.mentions.users.first() || message.author;

    // Get the user's avatar URL
    const avatarURL = user.displayAvatarURL({ format: 'png', dynamic: true, size: 4096 });

    // Create and send an embed with the user's avatar
    const embed = new MessageEmbed()
      .setColor('#7289DA') // Discord's default embed color
      .setTitle(`${user.username}'s Avatar`)
      .setImage(avatarURL)
      .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }));

    message.channel.send(embed);
  },
};
