require("dotenv").config();

module.exports = {
  token: process.env.TOKEN || '', // your discord bot token
  prefix: process.env.PREFIX || '!', // bot prefix
  ownerID: process.env.OWNERID || ['1170979888019292261'], //your discord id
  SpotifyID: process.env.SPOTIFYID || '6c31645ffb004ab8b44d06f7b96d1b66', // spotify client id
  SpotifySecret: process.env.SPOTIFYSECRET || '3618fdc0b4824cfd91a8d425dac32987', // spotify client secret
  mongourl: process.env.MONGO_URI || '', // MongoDb URL
  embedColor: process.env.COlOR || '#2B2928', // embed colour
  logs: process.env.LOGS || '', // Discord channel id 
  links: {
    support: process.env.SUPPORT || '',
    invite: process.env.INVITE || '',
    vote: process.env.VOTE || '',
    bg: process.env.BG || 'https://cdn.discordapp.com/attachments/1104280548668624936/1171033377751695441/standard_1.gif?ex=659bce52&is=65895952&hm=48f3aabcff62e643b48d32a2431c6757293edeb6bd52b55117e7b37b8a4280b9&'
  },

  nodes: [
    {
      url: process.env.NODE_URL || 'lavalink.oryzen.xyz',
      name: process.env.NODE_NAME || 'lavalink.oryzen.xyz',
      auth: process.env.NODE_AUTH || 'oryzen.xyz',
      secure: parseBoolean(process.env.NODE_SECURE || 'false'),
    },
  ],
};

function parseBoolean(value){
    if (typeof(value) === 'string'){
        value = value.trim().toLowerCase();
    }
    switch(value){
        case true:
        case "true":
            return true;
        default:
            return false;
    }
}
